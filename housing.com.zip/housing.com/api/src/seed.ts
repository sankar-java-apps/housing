// src/seed.ts
import { db } from './db'
import { v4 as uuid } from 'uuid'

export async function seedInitialData() {
  await db.read()

  if (!db.data) return

  if (db.data.cities.length === 0) {
    db.data.cities.push(
      { id: uuid(), name: 'Kuala Lumpur' },
      { id: uuid(), name: 'Penang' },
      { id: uuid(), name: 'Johor Bahru' },
      { id: uuid(), name: 'Langkawi' }
    )
  }

  if (db.data.agents.length === 0) {
    db.data.agents.push(
      { id: uuid(), name: 'Agent A' },
      { id: uuid(), name: 'Agent B' },
      { id: uuid(), name: 'Agent C' }
    )
  }

  await db.write()
}

