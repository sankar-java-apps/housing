import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { User } from '../db'

const SALT_ROUNDS = 10
const JWT_SECRET = process.env.JWT_SECRET || 'fallbacksecret'

export function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS)
}

export function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}

export function generateToken(user: User): string {
  return jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '1d',
  })
}

export function verifyToken(token: string): any {
  return jwt.verify(token, JWT_SECRET)
}

