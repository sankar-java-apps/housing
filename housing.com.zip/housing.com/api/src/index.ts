import express from 'express'
import cors from 'cors'
import morgan from 'morgan'
import { initDB } from './db'
import authRoutes from './routes/auth'
import dotenv from 'dotenv'
import { authMiddleware } from './middleware/authMiddleware'
import propertyRoutes from './routes/properties'
import { seedInitialData } from './seed'
import metaRoutes from './routes/meta'
import { asyncHandler } from './utils/asyncHandler'
import { setupSwagger } from './swagger'

const app = express()
const PORT = process.env.PORT || 5000
setupSwagger(app)

app.use(cors())
app.use(express.json())
app.use(morgan('dev'))

dotenv.config()

app.use('/auth', authRoutes)

app.get('/', (_req, res) => {
  res.send('Housing.com API is running')
})

app.get('/private', authMiddleware, (req, res) => {
  res.json({ message: 'You are authenticated!' })
})

app.use('/properties', propertyRoutes)

app.use('/', metaRoutes)

app.use('/auth', authRoutes)
app.use('/properties', propertyRoutes)
app.use('/', metaRoutes)

// Handle 404
app.use((_req, res) => {
  res.status(404).json({ error: 'Route not found' })
})

// Global error handler
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('Error:', err)
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error',
  })
})

console.log('initDB:', initDB);

initDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`)
  })
})

