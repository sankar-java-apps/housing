import { Router } from 'express'
import { db } from '../db'
import { hashPassword, comparePassword, generateToken } from '../utils/auth'
import { v4 as uuid } from 'uuid'
import { asyncHandler } from '../utils/asyncHandler'

const router = Router()


/**
 * @swagger
 * tags:
 *   name: Auth
 *   description: User authentication
 */

/**
 * @swagger
 * /auth/register:
 *   post:
 *     summary: Register a new user
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - email
 *               - password
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *               role:
 *                 type: string
 *                 enum: [user, agent, admin]
 *     responses:
 *       201:
 *         description: User registered successfully
 *       400:
 *         description: Email already exists
 */


// Register
router.post('/register', async (req, res) => {
  const { name, email, password, role } = req.body

  await db.read()
  const existingUser = db.data?.users.find(u => u.email === email)
  if (existingUser) return res.status(400).json({ error: 'Email already exists' })

  const hashed = await hashPassword(password)
  const newUser = {
    id: uuid(),
    name,
    email,
    password: hashed,
    role: role || 'user',
  }

  db.data?.users.push(newUser)
  await db.write()

  res.status(201).json({ message: 'User registered successfully' })
})

// Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body

  await db.read()
  const user = db.data?.users.find(u => u.email === email)
  if (!user) return res.status(400).json({ error: 'Invalid credentials' })

  const valid = await comparePassword(password, user.password)
  if (!valid) return res.status(400).json({ error: 'Invalid credentials' })

  const token = generateToken(user)
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } })
})


router.get('/', asyncHandler(async (req, res) => {
  // safe, errors will be forwarded to global handler
}))

export default router

