import { Router } from 'express'
import { db } from '../db'
import { asyncHandler } from '../utils/asyncHandler'

const router = Router()

router.get('/cities', async (_req, res) => {
  await db.read()
  res.json(db.data?.cities || [])
})

router.get('/agents', async (_req, res) => {
  await db.read()
  res.json(db.data?.agents || [])
})

router.get('/', asyncHandler(async (req, res) => {
  // safe, errors will be forwarded to global handler
}))

export default router

