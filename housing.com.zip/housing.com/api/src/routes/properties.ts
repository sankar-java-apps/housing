import { Router } from 'express'
import { v4 as uuid } from 'uuid'
import { db, Property } from '../db'
import { authMiddleware } from '../middleware/authMiddleware'
import { asyncHandler } from '../utils/asyncHandler'

const router = Router()

// GET /properties - Get all properties
router.get('/', async (req, res) => {
  await db.read()
  let properties = db.data?.properties || []

  // Extract query parameters
  const {
    city,
    type,
    minPrice,
    maxPrice,
    page = '1',
    limit = '10',
  } = req.query

  // Filter by city
  if (city && typeof city === 'string') {
    properties = properties.filter(p => p.city.toLowerCase() === city.toLowerCase())
  }

  // Filter by type
  if (type && typeof type === 'string') {
    properties = properties.filter(p => p.type.toLowerCase() === type.toLowerCase())
  }

  // Filter by minPrice
  if (minPrice && !isNaN(Number(minPrice))) {
    properties = properties.filter(p => p.price >= Number(minPrice))
  }

  // Filter by maxPrice
  if (maxPrice && !isNaN(Number(maxPrice))) {
    properties = properties.filter(p => p.price <= Number(maxPrice))
  }

  // Pagination
  const pageNum = Math.max(parseInt(page as string, 10), 1)
  const limitNum = Math.max(parseInt(limit as string, 10), 1)
  const start = (pageNum - 1) * limitNum
  const end = start + limitNum

  const paginated = properties.slice(start, end)

  res.json({
    page: pageNum,
    limit: limitNum,
    total: properties.length,
    results: paginated,
  })
})


// GET /properties/:id - Get property by ID
router.get('/:id', async (req, res) => {
  await db.read()
  const property = db.data?.properties.find(p => p.id === req.params.id)
  if (!property) return res.status(404).json({ error: 'Property not found' })
  res.json(property)
})

// POST /properties - Create new property (auth required)
router.post('/', authMiddleware, async (req, res) => {
  const { title, description, price, city, type, imageUrl } = req.body
  const user = (req as any).user

  const newProperty: Property = {
    id: uuid(),
    title,
    description,
    price,
    city,
    type,
    imageUrl,
    agentId: user.id,
  }

  await db.read()
  db.data?.properties.push(newProperty)
  await db.write()

  res.status(201).json(newProperty)
})

// PUT /properties/:id - Update property (auth required)
router.put('/:id', authMiddleware, async (req, res) => {
  const { id } = req.params
  const user = (req as any).user

  await db.read()
  const property = db.data?.properties.find(p => p.id === id)
  if (!property) return res.status(404).json({ error: 'Property not found' })

  if (property.agentId !== user.id) {
    return res.status(403).json({ error: 'You do not own this property' })
  }

  Object.assign(property, req.body)
  await db.write()
  res.json(property)
})

// DELETE /properties/:id - Delete property (auth required)
router.delete('/:id', authMiddleware, async (req, res) => {
  const { id } = req.params
  const user = (req as any).user

  await db.read()
  const index = db.data?.properties.findIndex(p => p.id === id)
  if (index === -1 || db.data?.properties[index!].agentId !== user.id) {
    return res.status(403).json({ error: 'Cannot delete this property' })
  }

  db.data!.properties.splice(index!, 1)
  await db.write()
  res.status(204).send()
})

router.get('/', asyncHandler(async (req, res) => {
  // safe, errors will be forwarded to global handler
}))

export default router

