// src/db.ts
import { Low } from 'lowdb'
import { JSONFile } from 'lowdb/node'
import { join } from 'path'

export type Property = {
  id: string
  title: string
  description: string
  price: number
  city: string
  type: string
  agentId: string
  imageUrl?: string
}

export type User = {
  id: string
  name: string
  email: string
  password: string
  role: 'user' | 'agent' | 'admin'
}

export type City = {
  id: string
  name: string
}

export type Agent = {
  id: string
  name: string
}

type Data = {
  users: User[]
  properties: Property[]
  cities: City[]
  agents: Agent[]
}

const file = join(__dirname, '../db1.json')
const adapter = new JSONFile<Data>(file)
const db = new Low<Data>(adapter)

export async function initDB() {
  await db.read()
  db.data ||= {
    users: [],
    properties: [],
    cities: [],
    agents: [],
  }
  await db.write()
}

export { db }


